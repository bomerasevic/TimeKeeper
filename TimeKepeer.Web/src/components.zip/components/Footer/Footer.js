import React, { Component } from "react";
import "./Footer.css";

function Footer() {

  return(

    <footer>
    
      <p>
        Copyright &copy; by Gigi School of Coding. All rights reserved.
      </p>
    
  </footer>
 

  );


}

export default Footer;