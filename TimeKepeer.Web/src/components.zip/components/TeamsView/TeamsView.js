import React from "react";
import "./TeamsView.css";



class TeamsView extends React.Component {
    render() {
       
        return (
          
              
           
              <div className="container TeamsView">
               
            <div className="square">
                
            <div className="buttonsTeams">
            <button className="btn" id="edit">EDIT</button>
            <button className="btn" id="delete">DELETE</button>

            </div>

               
            </div>
            </div>
            
           
        );
    }
}
export default TeamsView;
