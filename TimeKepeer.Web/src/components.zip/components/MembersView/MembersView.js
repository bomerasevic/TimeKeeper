import React from "react";
import "./MembersView.css";



class MembersView extends React.Component {
    render() {
       
        return (
          
              
           
              <div className="container MembersView">
               
            <div className="squareMembers">
                
      

            </div>

               
            </div>
            
            
           
        );
    }
}
export default MembersView;